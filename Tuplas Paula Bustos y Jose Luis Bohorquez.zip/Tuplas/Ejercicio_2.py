#1) Escribir un Código que dados varios valores digitados por el
#usuario y separados por espacios, ejemplo: (5 30 HolaMundo),
#cree una tupla y la imprima por pantalla (puedes usar tuple())
#2) Escribe un algoritmo que me imprima las posiciones impares de la anterior tupla
#3) Escribe un Código que imprima la suma de los números de la
#anterior tupla (Cuando el usuario digita solo números)
#4) Escribe un Código que imprima el numero menor de la anterior
#tupla (Cuando el usuario digita solo números)
n = input("Digite varios valores separados por espacios: ")
tupla = tuple(n.split())

def posiciones_impares(tupla):
    for i in range(len(tupla)):
        if i % 2 != 0:
            print(tupla[i])

def suma_numeros(tupla):
    suma = 0
    for i in range(len(tupla)):
        if tupla[i].isdigit():
            suma += int(tupla[i])
    print(suma)

def numero_menor(tupla):
    menor = tupla[0]
    for i in range(len(tupla)):
        if tupla[i].isdigit():
            if int(tupla[i]) < int(menor):
                menor = tupla[i]
    print(menor)

print(tupla)
numero_menor(tupla)
posiciones_impares(tupla)
suma_numeros(tupla)