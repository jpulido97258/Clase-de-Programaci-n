#Cree 2 tuplas, la primera va a contener: ("UsuarioEAN"), y la
#segunda ("Uean2022") las cuales corresponden a las credenciales
#del usuario.

#Cree un algoritmo que le pregunte al usuario sus credenciales.
#primero su user("UsuarioEAN") y luego su contraseña("Uean2022"),
#en caso de que digite mal su user el código deberá imprimir un
#mensaje que diga "Este usuario no existe, por favor intente
#nuevamente",  esta acción se deberá repetir hasta que la persona
#escriba correctamente el user, una vez escriba correctamente su
#user tendrá que escribir la contraseña, si su contraseña  es
#incorrecta deberá imprimir un mensaje que diga "Contraseña
#incorrecta intenta nuevamente", y se repita infinitamente hasta
#que el usuario digite bien su contraseña.


cont= 1
while True:
    usuario = input("digite el usuario: ")
    tupla = tuple(usuario.split())

    contraseña = input("digite su contraseña: ")
    tupla = tuple(contraseña.split())
    cont=cont+1
    if "usuarioean" == usuario and "uean2022" == contraseña:
        print("Funciono")
        break
    else:
        print("Esta mal")

