#Para la tupla A = ("Taller","Algoritmos","Programación",[2,9,2022]) Hacer:     
#1) Escribir los primeros 3 valores de la tupla solo utilizando una linea de código, (Utiliza el Slicing)
#2) Imprimir si el string ("Taller") se encuentra en la tupla (La salida es un valor booleano)
#3) Imprimir en que posición de la tupla se encuentra la palabra "Programación" (Utiliza Index)
#5) Imprimir la longitud de la tupla
#6) Escribe un código que a partir de la tupla cree una lista y la imprima por pantalla

tupla = ("Taller","Algoritmos","Programación",[2,9,2022])
print(tupla[:3])

if "Taller" in tupla:
    print("¿La palabra taller se encuentra en tupla?", bool(tupla))
else:
    print("La palabra taller no esta en la tupla")

index = tupla.index("Programación")
print("Teniendo en cuenta que se cuenta a partir del 0, la palabra programacion se encuentra en la posicion", index, "La longitud de la tupla es de:", len(tupla))

lista = []
n = int(input("¿Cuantos elementos quieres agregar a la lista?: "))
for elemento in range(n):
    palabra = input(f'Ingrese elementos {elemento}: ')
    lista.append(palabra)
    print(lista)
continuar = input("¿Desea insertar o eliminar algún elemento de la lista? Escriba si o no ")
if continuar == "si":
    insertar = input("(1)Insertar (2)Eliminar un elemento de la lista")
    if insertar == "1":
        palabra = input(f'Ingrese palabra {elemento}: ')
        lista.append(palabra)
        print(lista, "\nGracias por participar","\nprograma finalizado")
    elif insertar == "2":
        palabra = input(f'Ingrese palabra {elemento}: ')
        lista.remove(palabra)
        print (lista, "\nGracias por participar","\nprograma finalizado")
elif continuar == "no":
    print(tupla, lista, "\nGracias por participar","\nprograma finalizado")