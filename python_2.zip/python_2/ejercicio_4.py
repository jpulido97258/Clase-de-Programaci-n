#Escriba su nombre,apellido y edad 



nombre=input("name: ")
apellido=input("lastname: ")
edad=int(input("age: "))

if edad >= 18:
    print("es mayor de edad")
else:
    print ("es menor de edad")