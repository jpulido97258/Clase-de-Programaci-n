# este es mi ejercicio numero 2
x = 2
y = 3
z = x+y
print ("Hola mundo" ,z)
