usuario=str(input("Ingrese su usuario: "))
contraseña=str(input("Ingrese un numero: "))
res = Elpapiadrian #podemos calcular la variable con un operador
res2 = joseesgay07 #""
#print (" EL RESULTADO INICIAL ES: ",res)
#2print ("EL RESULTADO SECUNDARIO ES: ",res2)

#booleano

if usuario != res :
    print ("El usuario es incorrecto")
else:
    print("usuario Correcto")

if contraseña != res2:
    print ("La contraseña es incorrecta")
else:
    print ("contraseña correcta")