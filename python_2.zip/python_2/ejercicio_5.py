#Ejercicio multivariable

num1=float(input("Ingrese un numero: "))
num2=float(input("Ingrese un numero: "))
res = num1*2 #podemos calcular la variable con un operador
res2 = num2*2 #""
#print (" EL RESULTADO INICIAL ES: ",res)
#print ("EL RESULTADO SECUNDARIO ES: ",res2)

#booleano

if res != res2:
    print ("los numero son diferente,digite otros numero")
else:
    print("Correcto")
