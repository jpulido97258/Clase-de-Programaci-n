# funcion masa corporal


import math

peso = float (input ("INGRESE SU PESO CORPORAL"))#ingrese un valor numerico en kilogramos
estatura = float (input("INGRESE SU ESTATURA EN METROS"))#ingrese ubn valor numerico

IMC = round (peso/math.pow(estatura,2),1)# formula para sacar la potencia de el peso y la masa

print ("su IMC es de" +str(IMC))# me muestra el resultado en cadena de texto IMC

lista = [["composicion corporal","indice de masa corporal (IMC)"],["peso inferior al no"]]