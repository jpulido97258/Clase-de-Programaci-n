# variable multi funcion

def = (masa,estatura)
masa = input(float)
estatura = imput (float)
imc = masa / (estatura**2)
return imc


if masa = (20.5 y 30) 
else:
print ("esta en el peso ideal")
if estatura = (1.60 y 1.75)
else:
print("esta fuera del peso")


