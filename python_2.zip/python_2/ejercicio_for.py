#Este es el bucle For

print (" bienvenidos a nuestro codigo")

n = 15
num1= n%2

for i in range (n): #posicion inicial
    print ("El resultado va ser la posicion final", n,num1)
print ("El resultado final es el producto del conteo")