#Teorema de pitagoras

a=float(input("Inserte el valor de A: "))
b=float(input("Inserte el valor de B: "))

res = ((a**2)+(b**2))**(1/2)

print ("la hipotenusa es: ",res)