# Ejercicio 2
x=2
y=3
z=(x+y)
print ("hola mundo", (x+y))

