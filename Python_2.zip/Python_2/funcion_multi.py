# Funcion masa corporal

import math


peso= float (input("ingrese su peso corporal:")) #Ingresa un valor numericoen kilogramos
estatura= float(input("ingrese su estatura en metros:"))#Ingresa el valor numerico

IMC= round (peso/math.pow(estatura,2),1)#Formula para sacar la potencia del peso y

print ("Su IMC es de" +str(IMC))#Me muestra el resultado en cadena de texto IMC

lista = (("Composicion corporal","Indice de masa corporal (IMC)"),("Peso inferior al no"))
