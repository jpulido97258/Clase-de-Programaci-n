

val1 = (3%5)
val2 = (5%2)

res = (val1+val2)

print (res)