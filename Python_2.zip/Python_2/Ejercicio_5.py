#Ejercicio Multivariables

from ast import If


num1=str(input ("Digite una contraseña:"))
num2=str(input ("Digite nuevamente su contraseña:"))
resultado1= num1 #Podemos calcular la variable con un operador
resultado2 = num2 #""
#print ("El resultado inicial es: ", resultado1)
#print ("El resultado secundario es:",resultado2)

#booleano

if resultado1 != resultado2:
    print ("Verifique la contraseña")
else:
    print("Correcto")