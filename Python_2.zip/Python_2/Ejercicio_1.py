# Este es mi primer programa de Python
x=1
y=2
print (x,y)