#Ecuacion cuadratica

a= float(input ("Digite el valor de a:"))
b= float(input ("Digite el valor de b:"))
c= float(input ("Digite el valor de c:"))
res1= ((-b)+(((b**2)-(4*a*c))**(1/2)))/(2*a)
res2= ((-b)-(((b**2)-(4*a*c))**(1/2)))/(2*a)
print ("El primer resultado es:", res1)
print ("El segundo resultado es:", res2)