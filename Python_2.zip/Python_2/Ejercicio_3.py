#Escriba su nombre y apellido donde se le indica
Usuario = input("Por favor digita tu nombre y apellido")
Edad = int(input("Ingresa tu edad"))

if Edad >= 18:
    print("Señor ususario", Usuario, "eres mayor de edad")
else:
    print("Señor usuasio", Usuario,"eres menor de edad")
