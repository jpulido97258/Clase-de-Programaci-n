# otro comando que se utiliza mucho en for

import traceback


nums = (3,5,6,3,1)
it = iter (nums)
next (it)
traceback