#Otros tipos de comandos

nums = (1,3,5,6,7)
for n in nums:
    print(nums)
