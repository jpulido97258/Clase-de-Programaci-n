 
from msvcrt import kbhit


usuario = str(input ("Introduzca su usuario: "))
n= "Jose"
for i in usuario :
        if n == usuario :
            print("Usuario correcto")
            break
        else:
            print ("El usuario es incorrecto")
            break
usuario = str(input ("Introduzca su usuario: "))
k= "Jose"
for l in usuario :
        if k == usuario :
            print("contraseña correcto")
            break
        else:
            print ("contraseña incorrecto")
            break